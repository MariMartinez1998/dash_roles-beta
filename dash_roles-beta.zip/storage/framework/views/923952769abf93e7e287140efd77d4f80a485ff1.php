<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Correo Electronico</h1>
    <p>Usuario Registrado Exitosamente</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\dash_roles(beta)\resources\views/emails/registro.blade.php ENDPATH**/ ?>