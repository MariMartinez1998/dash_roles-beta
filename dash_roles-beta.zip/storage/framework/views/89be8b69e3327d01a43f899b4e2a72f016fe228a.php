

<?php $__env->startSection('content'); ?>
<section class="section">
  <div class="section-header">
      <h3 class="page__heading">Users</h3>
  </div>
      <div class="section-body">
          <div class="row">
              <div class="col-lg-12">
                  <div class="card">
                      <div class="card-body">      
                        
                      <?php echo Form::model($user, ['method' => 'PATCH','route' => ['usuarios.show', $user->id]]); ?>

                            <table class="table table-striped mt-2">
                              <thead style="background-color:#6777ef">                                     
                                  <th style="color:#fff;">Name</th>
                                  <th style="color:#fff;">Last name</th>
                                  <th style="color:#fff;">E-mail</th>  
                                  <th style="color:#fff;">Phone</th>
                                  <th style="color:#fff;">City</th>
                                  <th style="color:#fff;">Street</th>
                                  <th style="color:#fff;">State</th>
                                  <th style="color:#fff;">Zip Code</th>
                                                                                                     
                              </thead>
                              <tbody>
                                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                   
                                    <td><?php echo e($usuario->name); ?></td>
                                    <td><?php echo e($usuario->last_name); ?></td>
                                    <td><?php echo e($usuario->email); ?></td>
                                    <td><?php echo e($usuario->phone); ?></td>
                                    <td><?php echo e($usuario->city); ?></td>
                                    <td><?php echo e($usuario->street); ?></td>
                                    <td><?php echo e($usuario->state); ?></td>
                                    <td><?php echo e($usuario->zip_code); ?></td>
                                   
                                  </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </tbody>
                            </table>
                            <?php echo Form::close(); ?>

                            
                      </div>
                  </div>
              </div>
          </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dash_roles(beta)\resources\views/usuarios/vista.blade.php ENDPATH**/ ?>