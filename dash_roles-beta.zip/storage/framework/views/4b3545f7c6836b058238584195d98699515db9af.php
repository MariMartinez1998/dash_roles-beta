<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="section-header">
            <h3 class="page__heading">Services</h3>
        </div>
        <div class="section-body">
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                
            
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-service')): ?>
                        <a class="btn btn-warning" href="<?php echo e(route('blogs.create')); ?>">New</a>
                        <?php endif; ?>
            
                        <table class="table table-striped mt-2">
                                <thead style="background-color:#6777ef">                                     
                                    <th style="color:#fff;">ID</th>
                                    <th style="color:#fff;">ID-user</th>
                                    <th style="color:#fff;">Title</th>
                                    <th style="color:#fff;">Description</th> 
                                    
                                    <th style="color:#fff;">Image</th>          
                                    <th style="color:#fff;">Actions</th>                                                                   
                              </thead>
                              <tbody>
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($blog->id); ?></td>    
                                <td><?php echo e($blog->id_users); ?></td>                              
                                <td><?php echo e($blog->titulo); ?></td>
                                <td><?php echo e($blog->contenido); ?></td>
                               
                                <td class="border px-14 py-1">
                                    <img src="/imagen/<?php echo e($blog->image); ?>" height="150" alt="">
                                </td>
                                <td>
                                    <form action="<?php echo e(route('blogs.destroy',$blog->id)); ?>" method="POST">                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-service')): ?>
                                        <a class="btn btn-info" href="<?php echo e(route('blogs.edit',$blog->id)); ?>">Edit</a>
                                        <?php endif; ?>

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-service')): ?>
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <!-- Ubicamos la paginacion a la derecha -->
                        <div class="pagination justify-content-end">
                            <?php echo $blogs->links(); ?>

                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dash_roles(beta)\resources\views/blogs/index.blade.php ENDPATH**/ ?>