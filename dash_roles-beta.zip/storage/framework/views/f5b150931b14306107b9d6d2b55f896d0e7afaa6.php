

<li class="side-menus <?php echo e(Request::is('*') ? 'active' : ''); ?>">
    <a class="nav-link" href="/home">
        <i class=" fas fa-building"></i><span>Home</span>
    </a>
    <a class="nav-link" href="/usuarios">
        <i class=" fas fa-users"></i><span>Users</span>
    </a>
    <a class="nav-link" href="/roles" style="display: none;">
        <i class=" fas fa-user-lock"></i><span>Roles</span>
    </a>
    <a class="nav-link" href="/blogs">
        <i class=" fas fa-car"></i><span>Services</span>
    </a>
</li>
<?php /**PATH C:\xampp\htdocs\dash_roles(beta)\resources\views/layouts/menu.blade.php ENDPATH**/ ?>