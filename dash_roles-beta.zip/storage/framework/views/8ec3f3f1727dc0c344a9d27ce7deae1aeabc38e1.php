<div class="footer-left">
    Design:HG Max Tec. &copy; <?php echo e(date('Y')); ?>

</div>
<?php /**PATH C:\xampp\htdocs\dash_roles(beta)\resources\views/layouts/footer.blade.php ENDPATH**/ ?>