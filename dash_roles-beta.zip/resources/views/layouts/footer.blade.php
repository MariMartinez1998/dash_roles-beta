<div class="footer-left">
    Design:HG Max Tec. &copy; {{ date('Y') }}
</div>
